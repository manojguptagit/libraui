import { LibraUiPage } from './app.po';

describe('libra-ui App', () => {
  let page: LibraUiPage;

  beforeEach(() => {
    page = new LibraUiPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
